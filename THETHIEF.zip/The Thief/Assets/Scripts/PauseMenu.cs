﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour {

    public GameObject ui;
    public GameObject ui2;
    public string LevelLoading = "MainMenu";

	void Start () {
		
	}
	
	void Update () {
        if (Input.GetButtonDown("Cancel"))
        {
            PausingToggle();
        }

    }

   public void PausingToggle()
    {
        ui.SetActive(!ui.activeSelf);

        if (ui.activeSelf)
        {
           
            Time.timeScale = 0f;
        }
        else
        {
            
            Time.timeScale = 1f;
        }

    }
    public void OptionsCloser()
    {
       ui2.SetActive(!ui2.activeSelf);

    }

    
    public void MainMenu()
    {
        SceneManager.LoadScene(LevelLoading);
        Time.timeScale = 1f;
    }
    public void Exit()
    {
        Application.Quit();
        Debug.Log("The game has been exited");
    }

}
