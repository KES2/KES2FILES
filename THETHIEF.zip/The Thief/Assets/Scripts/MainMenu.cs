﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public string LevelLoading = "Game";
    public GameObject ui;
    public void Play()
    {
        SceneManager.LoadScene(LevelLoading);
        
    }
    public void OptionsCloser()
    {
       ui.SetActive(!ui.activeSelf);

    }

    
    public void Exit()
    {
        Application.Quit();
        Debug.Log("The game has been exited");
    }
}
