﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomTransition : MonoBehaviour
{
    public GameObject currentroom;
    public GameObject nextroom;
    public Transform spawnpoint;
    
     public Transform player;

    void OnTriggerEnter2D(Collider2D other)
    {
       
        if(other.tag == "Player"){
            nextroom.SetActive(true);
            RoomChange();
            currentroom.SetActive(false);
        }
   
    }
    public void RoomChange()
    {
        player.transform.position = spawnpoint.transform.position;
    }
}
