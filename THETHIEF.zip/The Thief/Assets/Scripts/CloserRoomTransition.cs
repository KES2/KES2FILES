﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloserRoomTransition : MonoBehaviour
{
    
   public GameObject currentroom;
    public GameObject nextroom;
    public Transform spawnpoint;
    
     public Transform player;

    void OnTriggerStay2D(Collider2D other)
    {
       
        if((other.tag == "Player") && Input.GetKeyDown(KeyCode.X) ){
            nextroom.SetActive(true);
            RoomChange();
            currentroom.SetActive(false);
        }
   
    }
    public void RoomChange()
    {
        player.transform.position = spawnpoint.transform.position;
    }
}
